define( [
	"../../core",
	"../../selector"
], function( jQuery ) {
	return jQuery.expr.match.needsContext;
} );
